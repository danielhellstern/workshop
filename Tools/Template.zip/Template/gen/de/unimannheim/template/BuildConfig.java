/** Automatically generated file. DO NOT MODIFY */
package de.unimannheim.template;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}